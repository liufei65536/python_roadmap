# Algorithms & data structures project

This repository presents the Python and C++ code implementation of the provided Algorithms and data structures from William Fiset at:
https://github.com/williamfiset/Algorithms


# Contributing

If you'd like to add or improve an algorithm, your contribution is welcome!


# License

This repository is released under the [MIT license](https://opensource.org/licenses/MIT). In short, this means you are free to use this software in any personal, open-source or commercial projects. Attribution is optional but appreciated.
